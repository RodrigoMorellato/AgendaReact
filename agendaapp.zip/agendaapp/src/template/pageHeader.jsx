import React from 'react'
import Grid from '../template/grid'

export default props => (
    <header className='page-header'>
        <b>{props.name}</b>
    </header>
)